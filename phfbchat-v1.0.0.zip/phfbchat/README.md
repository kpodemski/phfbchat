# PrestaHome - Free module to display Facebook Messenger chat on your store

### How to use?

- [ ] Download module
- [ ] Get your Facebook Page ID by going to https://findmyfbid.com
- [ ] Install module from Modules tab
- [ ] Go to the Configuration page of module
- [ ] Set Page ID, App ID and Langauge code

### Requirements

* PHP 5.4
* PrestaShop 1.6.1.6+
# PrestaHome - Free module to display Facebook Messenger chat in your store

### How to use?

- [ ] Download module from: http://bit.ly/prestahome-facebook-messenger
- [ ] Get your Facebook Page ID by going to [here](https://commentpicker.com/find-facebook-id.php)
- [ ] Install module from Modules tab
- [ ] Go to the Configuration page of the module
- [ ] Set Page ID, Langauge code and rest of the settings

### Support

I'll try my best to help you, tho module is for free, you can always create an Issue here on repository page

Want to support me? Buy me a coffe :) [https://paypal.me/kpodemski](https://paypal.me/kpodemski)

### Requirements

* PHP 5.4
* PrestaShop 1.6.1.6+

### Created by [Krystian Podemski](https://www.podemski.dev) from [PrestaHome](http://www.prestahome.com)

### My products

* Modules on CodeCanyon [here](https://codecanyon.net/user/prestahome/portfolio?ref=prestahome)
* Themes on ThemeForest [here](https://themeforest.net/user/prestahome/portfolio?ref=prestahome)
* More modules, and more themes, on PrestaShop Addons Marketplace [here](https://addons.prestashop.com/en/111_prestahome)

![PrestaHome](http://www.prestahome.com/cover.jpg)
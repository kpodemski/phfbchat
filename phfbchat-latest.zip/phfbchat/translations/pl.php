<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{phfbchat}prestashop>phfbchat_36951a34e7beef6681ecff38576b53fb'] = 'Facebook Messenger dla PrestaShop';
$_MODULE['<{phfbchat}prestashop>phfbchat_923f053c0db3f82e353b488a6780a6e2'] = 'Moduł do wyświetlania Facebook Messenger w Twoim sklepie';
$_MODULE['<{phfbchat}prestashop>phfbchat_8dd2f915acf4ec98006d11c9a4b0945b'] = 'Ustawienia poprawnie zaktualizowane';
$_MODULE['<{phfbchat}prestashop>phfbchat_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{phfbchat}prestashop>phfbchat_48440222ff91e4921b171db9b70b00cd'] = 'Udaj się do Twoja strona na FB -> Ustawienia -> Messenger -> White-listed domains i dodaj domenę swojego sklepu aby Facebook Messenger mógł zostać wyświetlony';
$_MODULE['<{phfbchat}prestashop>phfbchat_35c4b9eadafea9752b83bc91399d2716'] = 'Więcej informacji: https://developers.facebook.com/docs/apps/register';
$_MODULE['<{phfbchat}prestashop>phfbchat_22de55a116ffd25b07ae2282387a3369'] = 'ID Twojej strony:';
$_MODULE['<{phfbchat}prestashop>phfbchat_06e34e72411dcce2f04a1ca2479d3e36'] = 'Możesz użyć https://findmyfbid.com/ aby znaleźć swoje ID';
$_MODULE['<{phfbchat}prestashop>phfbchat_01a3b3d8af14e844c49a3a5acc870c6b'] = 'Kod języka:';
$_MODULE['<{phfbchat}prestashop>phfbchat_df3d2d0d5cea8c2d3025827aa6144e2c'] = 'np. pl_PL, en_EN, więcej informacji: https://developers.facebook.com/docs/internationalization';
$_MODULE['<{phfbchat}prestashop>phfbchat_231cf4c70d866b616c21baddaeed0696'] = 'Rozwiązywanie problemów';
$_MODULE['<{phfbchat}prestashop>phfbchat_6bc9a010005d72d4aab716b506de3621'] = 'Inicjalizować skrypt API FB?';
$_MODULE['<{phfbchat}prestashop>phfbchat_93cba07454f06a4a960172bbd6e2a435'] = 'Tak';
$_MODULE['<{phfbchat}prestashop>phfbchat_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nie';
$_MODULE['<{phfbchat}prestashop>phfbchat_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{phfbchat}prestashop>prestahomeconfiguratorbase_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{phfbchat}prestashop>prestahomehelpers_882ee81198523d5a26bc7a2d30a93398'] = '-- Wybierz --';
$_MODULE['<{phfbchat}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Wybierz plik';
$_MODULE['<{phfbchat}prestashop>form_01778e61e411e7ba0d37d6c27b84d440'] = 'Wybierz obrazek';
